<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>Kategori barang</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="container">
			<h3><left>==kategori barang==</left></h3>
			<label class="col-md-6 offset-md-3">Barang</label>
			<div class="col-md-3">
				<select class="form-control" id="kode" name="kode">
					<option selected="0">pilih barang..</option>

					<?php foreach($brg as $cat) : ?>
					<option value="<?php echo $cat->Barang_id;?>"><?php echo $cat->Nama_barang; ?>-<?php echo $cat->Harga_barang;
						?>
					</option>
					<?php endforeach;	?>
				</select>
			</div>
				<div class="col-md-3">
				<label>Nama Barang</label>
				<input class="form-control" id="barang" name="barang" readonly>	
			</div>
			    <div class="col-md-3">
				<label>Harga Barang</label>
				<input class="form-control" id="harga" name="harga" readonly>
					
		</div>
		</div>
		</div>
		<!--jquery-->
		<script src="<?php echo base_url().'assets/js/jquery.js'?>"></script>
		<script type="text/javascript">
		
		$(document).ready(function()
		{
			$('#kode').change(function()
		{
			var	barang=$(this).val();
			alert(barang);
			$.ajax(
		{
		url : "<?php echo base_url('kategori/get_barang')?>",
		method 	 :"POST",
		dataType :'json',
				data:{kode:barang},
				cache:false,
		async :true,
				success:function(data)
			{
				$.each(data,function(Barang_id,Nama_barang,Harga_barang)
				{
					$('[name="barang"]').val(data.Nama_barang);
					$('[name="harga"]').val(data.Harga_barang);
				});
			}
		})

return false
	});	
	});
		</script>	
</body>	
</html>