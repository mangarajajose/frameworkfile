<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>Nomor Invoice</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<form action="<?php echo base_url('Invoice/simpan_invoice')?>"
		method="post">
		<input type="text" name="no_invoice" value="<?php echo $invoice;?>" readonly>
		<button type="submit">Simpan</button>
	</form>


</body>

</html>