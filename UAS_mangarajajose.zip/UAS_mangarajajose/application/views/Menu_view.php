<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url ('assets/img/database.ico') ?>" rel="shortcut icon" >
<head>
	<meta charset="utf-8">
	<title>Aplikasi Kelola Data</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
	<!--front-->
	<link href="<?php echo base_url ('assets/css/font-awesome.css');?>" rel="stylesheet">
</head>
<?php
	$this->load->view('Navbar_view');
	?>
<!--image--> <br><br>
<div class="row">
	<div class="col-md-4">
	</div>
	<div class="col-md-4">
		<center><div class="thumbnail"></center>
			<a href="assets/img/tokobaju.jpg" target="blank">
				<img src="assets/img/tokobaju.jpg" alt="tokobaju" style="width: 100%;">
				<div class="caption"></div>
			</a>
		</div>
	</div>
	<div class="col-md-4">
	</div>

	<div class="row">
		<br><br>
		<center><p>Created By : Mangaraja Jose@ <?php 	echo date('Y'); ?></p><hr>	</center>
	</div>
</div>
</html>
