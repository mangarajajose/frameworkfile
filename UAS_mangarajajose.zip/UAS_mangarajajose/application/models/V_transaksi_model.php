<?php 

 class V_transaksi_model extends CI_Model
{
 	
	function tampil_data()
	{
		$hasil=$this->db->get('v_transaksi');
		return $hasil;
	}
	function get_tampil_data()
	{
		$hasil=$this->db->get('v_transaksi')->result();
		return $hasil;
	}
 } ?>