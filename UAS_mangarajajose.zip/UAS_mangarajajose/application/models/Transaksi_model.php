<?php
class Transaksi_model extends CI_Model
{
	     function get_faktur()
    {
      $q=$this->db->query("select max(right(faktur,5)) as kd_max
        from transaksi where date(tanggal)=CURDATE()");
      $kd="";
      if($q->num_rows()>0)
      {
        foreach ($q->result() as $k)
         {
          $tmp = ((int)$k->kd_max)+1;
          $kd=sprintf("%05s",$tmp);
        }
      }else{
        $kd="00001";
      }
      date_default_timezone_set("Asia/Jakarta");
      return "FK".date('dmy').$kd;
    }
    //reading kode customer
        function get_tampil_data()
    {
      $hasil=$this->db->get('customer')->result();
      return $hasil;	
    }
    function get_data_customer_bykode($kode)
    {
    	$hsl=$this->db->query("SELECT * FROM customer where kode_customer='$kode'");
    	if ($hsl->num_rows()>0) 
      {
    	foreach ($hsl->result() as $data) 
       {
           $hasil=array(
           	'kode_customer'=>$data->kode_customer,
           	'nama_customer'=>$data->nama_customer,
           );         
    	}
   	}
   	return $hasil;
  }
      function get_data_barang_bykode($kode)
    {
    	$hsl=$this->db->query("SELECT * FROM barang where barang_id='$kode'");
    	if ($hsl->num_rows()>0) 
      {
    	foreach ($hsl->result() as $data) 
       {
           $hasil=array(
           	'barang_id'=>$data->barang_id,
           	'nama_barang'=>$data->nama_barang,
           	'harga_barang'=>$data->harga_barang,
           	'stok'=>$data->stok,

           );         
    	}
   	}
   	return $hasil;
  }
  function get_tampil_data_barang()
    {
      $hasil=$this->db->get('barang')->result();
      return $hasil;	
    }
    //Coding simpan data ke Tabel Transaksi dan Detail Transaksi
    function simpan_transaksi($faktur,$customer,$total,$ppn,$bayar)
   {
    $this->db->query("INSERT INTO transaksi(Faktur,kode_customer,total,ppn,total_bayar) VALUES 
    ('$faktur','$customer','$total','$ppn','$bayar')");
    foreach ($this->cart->contents() as $item) {
      $data=array(
         'Faktur'=> $faktur,
         'barang_id'  =>  $item['id'],
         'qty' =>  $item['qty'],
         'subtotal' =>  $item['amount']
      );
      $this->db->insert('detail_transaksi',$data);
      //var_dump($data);exit;   
    }
    return true;
  }

}
?>