<?php
class Petugas_model extends CI_Controller
{
	
	function tampil_data()
{
		$hasil=$this->db->get('Petugas');

		return $hasil;
}
	function simpan($petugas,$shift)
{
	$data=array(
		'petugas'=>$petugas,
		'shift'=>$shift);
	$this->db->insert('Petugas',$data);		
}
	function hapus_data($kode_petugas)
{
	$this->db->where('kode_petugas',$kode_petugas);
	$this->db->delete('Petugas');		
}
	function get_data_id($kode_petugas)
{
	$query=$this->db->get_where('petugas',array('kode_petugas'=>$kode_petugas));
	return $query;		
}
	function update($kode_petugas,$petugas,$shift)
	{
		$data=array(
		'kode_petugas'=>$kode_petugas,
		'petugas'=>$petugas,
		'shift'=>$shift);
		$this->db->where('kode_petugas',$kode_petugas);
	
		$this->db->update('Petugas',$data);
	}
	function get_tampil_data()
	{
		$hasil=$this->db->get('Petugas')->result();
		return $hasil;
	}
	function get_data_petugas_bykode($kode)
	{
		$hsl=$this->db->query("SELECT * from petugas where kode_petugas='$kode'");
		if($hsl->num_rows()>0)
		{
			foreach ($hsl->result() as $data)
			{	
				$hasil=array(
					'kode_petugas'=>$data->kode_petugas,
					'petugas'=>$data->petugas,
					'shift'=>$data->shift,
				);
			}
		}
	return $hasil;
}
}
?>