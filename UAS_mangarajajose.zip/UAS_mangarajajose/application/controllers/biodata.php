<?php
class biodata extends CI_controller
{
	function Biodata()
	{
		echo "Nama Mahasiswa : Albert Boni <br>";
		echo "Alamat         : Pondok Ungu Permai Blok AD 14 N0.2 <br>";
		echo "Prodi          : MI <br>";
		echo "Kode Kelas     : 05421 <br>";
	}

}




?>