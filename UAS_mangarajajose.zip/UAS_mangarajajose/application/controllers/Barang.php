<?php
class Barang extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Barang_model');
	}
	function index()
	{
		$data['Barang']=$this->Barang_model->
		tampil_data();
		$this->load->view('Barang_view',$data);	
	}
		function simpan_barang()
	{
		$barang_id=$this->input->post('barang_id');
		$nama_barang=$this->input->post('nama_barang');
		$harga_barang=$this->input->post('harga_barang');
		$this->Barang_model->simpan_barang($barang_id,$nama_barang,$harga_barang);
		redirect('Barang');
	}
	function Delete_barang()
	{
		$barang_id=$this->uri->segment(3);	
		$this->Barang_model->hapus_data($barang_id);
		redirect('Barang');	
	}
	function Edit_barang()
	{
		$barang_id=$this->uri->segment(3);	
		$result=$this->Barang_model->get_data_id($barang_id);
		if ($result->num_rows()>0) 
	{
			$i=$result->row_array();
			$data=array(
			'barang_id'=>$i['barang_id'],
			'nama_barang'=>$i['nama_barang'],
			'harga_barang'=>$i['harga_barang'],
	);
			$this->load->view('Edit_barang_view',$data);
	}
		else 
	{
			echo "Data Tidak Ditemukan";
	}
	}
	function Update()
	{
		$barang_id=$this->input->post('barang_id');
		$nama_barang=$this->input->post('nama_barang');
		$harga_barang=$this->input->post('harga_barang');
		$this->Barang_model->update($barang_id,$nama_barang,$harga_barang);
		redirect('Barang');
	}
	function Add_barang()
	{
		$data['Barang']=$this->Barang_model->get_no_barang();
		$this->load->view('Add_barang',$data);
	}		
}
?>