<?php 
class V_transaksi extends CI_Controller
 {
 	
 	function __construct()
 	{
 		parent::__construct();
 		$this->load->model('V_transaksi_model');
 	}
 	function index()
 	{
 		$data['v_transaksi']=$this->V_transaksi_model->tampil_data();
		$this->load->view('V_transaksi_view',$data);
 	}
 } ?>