<?php
class Hello extends CI_Controller
{
	function index()
	{
		echo "Hello CI";
	}
	function biodata()
	{
		echo "Nama Mahasiswa	: Muhammad Liwaul Hamdi <br>";
		echo "Alamat			: Harapan Baru <br>";
		echo "Prodi 			: MI <br>";
		echo "Kode Kelas 		: 05421";
	}
	function hitung()
	{
		echo "Panjang		: 10 <br>";
		echo "Lebar			: 5 <br>";
		echo "Hasil Luas 	: 50";
	}
	function hitung2()
	{
		$p=10;
		$l=2;
		$luas=$p*$l;
		echo "Panjang 	: ".$p."<br>";
		echo "Lebar 	: ".$l."<br>";
		echo "Luas 		: ".$luas;
	}
}


?>