<?php
class Kategori extends CI_Controller
{
  function __construct()
	{
		parent::__construct();
		$this->load->model('Barang_model');	
	}

	function index()
	{
	 $data['brg']=$this->Barang_model->get_tampil_data();
	 $this->load->view('Kategori_view',$data);
	}
	function get_barang()
	{
		$kobar=$this->input->post('kode',TRUE);
		$data=$this->Barang_model->get_data_barang_bykode($kobar);
		echo json_encode($data);
	}
}
?>
