/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 10.1.36-MariaDB : Database - uas_mangarajajose
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`uas_mangarajajose` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `uas_mangarajajose`;

/*Table structure for table `barang` */

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `barang_id` varchar(11) NOT NULL,
  `nama_barang` varchar(30) NOT NULL,
  `harga_barang` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  PRIMARY KEY (`barang_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `barang` */

insert  into `barang`(`barang_id`,`nama_barang`,`harga_barang`,`stok`) values 
('BRG00001','sepatu',250000,0),
('BRG00002','celana',100000,0),
('BRG00003','jas',300000,0);

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `kode_customer` varchar(5) NOT NULL,
  `nama_customer` varchar(25) NOT NULL,
  PRIMARY KEY (`kode_customer`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

/*Table structure for table `detail_transaksi` */

DROP TABLE IF EXISTS `detail_transaksi`;

CREATE TABLE `detail_transaksi` (
  `faktur` varchar(5) NOT NULL,
  `barang_id` varchar(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `subtotal` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `detail_transaksi` */

insert  into `detail_transaksi`(`faktur`,`barang_id`,`qty`,`subtotal`) values 
('FK250','BRG00002',1,100000);

/*Table structure for table `transaksi` */

DROP TABLE IF EXISTS `transaksi`;

CREATE TABLE `transaksi` (
  `faktur` varchar(15) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kode_customer` varchar(5) NOT NULL,
  `total` double NOT NULL,
  `ppn` double NOT NULL,
  `total_bayar` double NOT NULL,
  `admin` varchar(50) NOT NULL,
  PRIMARY KEY (`faktur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transaksi` */

insert  into `transaksi`(`faktur`,`tanggal`,`kode_customer`,`total`,`ppn`,`total_bayar`,`admin`) values 
('FK25012200001','2022-01-25 17:55:13','',100000,10000,110000,'');

/*Table structure for table `v_barang` */

DROP TABLE IF EXISTS `v_barang`;

/*!50001 DROP VIEW IF EXISTS `v_barang` */;
/*!50001 DROP TABLE IF EXISTS `v_barang` */;

/*!50001 CREATE TABLE  `v_barang`(
 `nama_barang` varchar(30) ,
 `harga_barang` int(11) 
)*/;

/*Table structure for table `v_transaksi` */

DROP TABLE IF EXISTS `v_transaksi`;

/*!50001 DROP VIEW IF EXISTS `v_transaksi` */;
/*!50001 DROP TABLE IF EXISTS `v_transaksi` */;

/*!50001 CREATE TABLE  `v_transaksi`(
 `faktur` varchar(5) ,
 `barang_id` varchar(11) ,
 `nama_barang` varchar(30) ,
 `harga_barang` int(11) ,
 `qty` int(11) ,
 `subtotal` double 
)*/;

/*View structure for view v_barang */

/*!50001 DROP TABLE IF EXISTS `v_barang` */;
/*!50001 DROP VIEW IF EXISTS `v_barang` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_barang` AS select `barang`.`nama_barang` AS `nama_barang`,`barang`.`harga_barang` AS `harga_barang` from `barang` order by `barang`.`nama_barang` desc */;

/*View structure for view v_transaksi */

/*!50001 DROP TABLE IF EXISTS `v_transaksi` */;
/*!50001 DROP VIEW IF EXISTS `v_transaksi` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_transaksi` AS select `a`.`faktur` AS `faktur`,`a`.`barang_id` AS `barang_id`,`b`.`nama_barang` AS `nama_barang`,`b`.`harga_barang` AS `harga_barang`,`a`.`qty` AS `qty`,`a`.`subtotal` AS `subtotal` from (`detail_transaksi` `a` join `barang` `b` on((`a`.`barang_id` = `b`.`barang_id`))) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
