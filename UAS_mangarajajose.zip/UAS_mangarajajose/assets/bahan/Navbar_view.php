<!--<!DOCTYPE html>-->
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico');?>" rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>Aplikasi Kelola Barang</title>
	<!--load Bootsrap -->
	<link href="<?php echo base_url('
	assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
<!-- fonts-->
<link href="<?php echo base_url('assets/css/font-awesome.css');?>" rel="stylesheet">
</head>
<nav class="navbar navbar-expand navbar-dark bg-success static-top">

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link textbox-toggle" href="<?php echo base_url('Barang');?>" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">
                <i class="fa fa-book"></i> Data Kelola Barang
            </a>
        </li>
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link textbox-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">
                <i class="fa fa-user"></i> Biodata Programmer
            </a>
        </li>
    </ul>

</nav>
</html>