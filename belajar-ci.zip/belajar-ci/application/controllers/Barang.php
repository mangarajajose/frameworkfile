<?php
class Barang extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Barang_model');
	}
	function index()
	{
		$data['Barang']=$this->Barang_model->
		tampil_data();
		$this->load->view('Barang_view',$data);	
	}
		function simpan_barang()
	{
		$Barang_id=$this->input->post('Barang_id');
		$Nama_barang=$this->input->post('Nama_barang');
		$Harga_barang=$this->input->post('Harga_barang');
		$this->Barang_model->simpan_barang($Barang_id,$Nama_barang,$Harga_barang);
		redirect('Barang');
	}
	function Delete_barang()
	{
		$Barang_id=$this->uri->segment(3);	
		$this->Barang_model->hapus_data($Barang_id);
		redirect('Barang');	
	}
	function Edit_barang()
	{
		$Barang_id=$this->uri->segment(3);	
		$result=$this->Barang_model->get_data_id($Barang_id);
		if ($result->num_rows()>0) 
	{
			$i=$result->row_array();
			$data=array(
			'Barang_id'=>$i['Barang_id'],
			'Nama_barang'=>$i['Nama_barang'],
			'Harga_barang'=>$i['Harga_barang'],
	);
			$this->load->view('Edit_barang_view',$data);
	}
		else 
	{
			echo "Data Tidak Ditemukan";
	}
	}
	function Update()
	{
		$Barang_id=$this->input->post('Barang_id');
		$Nama_barang=$this->input->post('Nama_barang');
		$Harga_barang=$this->input->post('Harga_barang');
		$this->Barang_model->update($Barang_id,$Nama_barang,$Harga_barang);
		redirect('Barang');
	}
	function Add_barang()
	{
		$data['Barang']=$this->Barang_model->get_no_barang();
		$this->load->view('Add_barang',$data);
	}		
}
?>