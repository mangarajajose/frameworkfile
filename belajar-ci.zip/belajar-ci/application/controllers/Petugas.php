<?php
class Petugas extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Petugas_model');
	}
	function index()
	{
		$data['Petugas']=$this->Petugas_model->
		tampil_data();
		$this->load->view('Petugas_view',$data);	
	}
	function simpan_petugas()
	{
		$kode_petugas=$this->input->post('kode_petugas');
		$petugas=$this->input->post('petugas');
		$shift=$this->input->post('shift');
		$this->Petugas_model->simpan_petugas($kode_petugas,$petugas,$shift);
		redirect('Petugas');
	}
	function Delete_petugas()
	{
		$kode_petugas=$this->uri->segment(3);	
		$this->Petugas_model->hapus_data($kode_petugas);
		redirect('petugas');	
	}
	function Edit_petugas()
	{
		$kode_petugas=$this->uri->segment(3);	
		$result=$this->Petugas_model->get_data_id($kode_petugas);
		if ($result->num_rows()>0) 
	{
			$i=$result->row_array();
			$data=array(
			'kode_petugas'=>$i['kode_petugas'],
			'petugas'=>$i['petugas'],
			'shift'=>$i['shift'],
	);
			$this->load->view('Edit_petugas',$data);
	}
		else 
	{
			echo "Data Tidak Ditemukan";
	}
	}
	function update()
	{
		$kode_petugas=$this->input->post('kode_petugas');
		$petugas=$this->input->post('petugas');
		$shift=$this->input->post('shift');
		$this->Petugas_model->update($kode_petugas,$petugas,$shift);
		redirect('Petugas');
	}
	function Add_petugas()
	{
		$data['Petugas']=$this->Petugas_model->get_kode_petugas();
		$this->load->view('Add_petugas',$data);
	}		
}
?>