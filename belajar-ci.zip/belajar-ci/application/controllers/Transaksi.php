<?php
class Transaksi extends CI_Controller
{
    function __construct()
  {
    parent ::__construct();
    $this->load->model('Transaksi_model');
  }
  function index()
  {
    $data['faktur']=$this->Transaksi_model->get_no_faktur();
    $data['customer']=$this->Transaksi_model->get_tampil_data();
    $data['barang']=$this->Transaksi_model->get_tampil_data_barang();
    $this->load->view('Transaksi_view',$data);
  }
  function get_customer()
  {
     $kobar=$this->input->post('kode',true);
     $data=$this->Transaksi_model->get_data_customer_bykode($kobar);
     echo json_encode($data);
  }
   function get_barang()
  {
     $barang=$this->input->post('kode',true);
    $nama_barang=$this->input->post('kode',true);
    $harga_barang=$this->input->post('kode',true);
     $data=$this->Transaksi_model->get_data_barang_bykode($barang);
     echo json_encode($data);
  }
  //Coding untuk tambilkan detail Transaksi
  function add_to_cart()
  { 
  error_reporting(0);//fungsi Add To Cart
           //$faktur=$this->input->post('faktur');
       $a=$this->input->post('kode');
       $b= $this->input->post('nama_barang');
       $c=$this->input->post('harga');
       $d=$this->input->post('qty');
             $data = array(
               //'kode_bayar'=>$faktur,
         'id'       =>$a,
         'name'     =>$b,
         'qty'      =>$d,
          'price'    => str_replace(",", "",$c),
           'amount'   => str_replace(",", "", $c)*$d,
         );
         var_dump($data);exit;  
        $this->cart->insert($data);
    //$this->db->insert('tbl_detail_transaksi',$data);
        echo $this->show_cart(); //tampilkan cart setelah added
    }
 
function show_cart(){ //Fungsi untuk menampilkan Cart
        $output = '';
        $no = 0;
    $faktur=$this->input->post('faktur');
    //$data=$this->m_transaksi->get_transaksi($faktur);
        foreach ($this->cart->contents() as $items) {
            $no++;
            $output .='
                <tr>
          <td>'.$no.'</td>
          <td>'.$items['name'].'</td>
                    <td>'.$items['name'].'</td>
                         <td style="text-align:right;">'.number_format($items['price']).'</td>
             <td style="text-align:right;">'.number_format($items['qty']).'</td>  
            <td style="text-align:right;">'.number_format($items['amount']).'</td>
                        <td><button type="button" id="'.$items['rowid'].'" class="hapus_cart btn btn-danger btn-xs" style="width:100px">X</button></td>
                </tr>
            ';
        }
        return $output;
    }
 
function load_cart()
  { //load data cart
  error_reporting(1);
        echo $this->show_cart();
    }
 
    function hapus_cart()
  { //fungsi untuk menghapus item cart
      //$output='';
    //$faktur=$this->input->post('row_id');
        //$this->m_transaksi->del_transaksi($faktur);
    //echo $this->show_cart();
    //return $output;
    $output='';
        $data = array(
            'rowid' => $this->input->post('row_id'), 
            'qty' => 0, 
        );
        $this->cart->update($data);
        echo $this->show_cart();
        return $output;
    }
//coding simpan Transaksi
    function simpan_transaksi()
  {
    $total=$this->input->post('total');
    $faktur=$this->input->post('faktur2');
    $customer=$this->input->post('customer2');
    $ppn=str_replace(",", "", $this->input->post('ppn'));
    $bayar=str_replace(",", "", $this->input->post('total_bayar'));
    $jml_uang=str_replace(",", "", $this->input->post('jml_uang'));
    if(!empty($total) && $jml_uang>=0 && !empty($faktur))
    {
      $order_proses=$this->Transaksi_model->simpan_transaksi($faktur,$customer,$total,$ppn,$bayar);
        if($order_proses)
        {
          $this->cart->destroy();
        }
          echo $this->session->set_flashdata('msg','<label class="label label-success">Transaksi Sukses di Simpan</label>');
          redirect('Transaksi');
    }
    }

}
?>
