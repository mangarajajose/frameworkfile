<?php
class Invoice extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Invoice_model');
	}
	function index()
	{
		$data['invoice']=$this->Invoice_model->get_no_invoice();
		$this->load->view('Invoice_view',$data);	
	}
	function simpan_invoice()
	{
		$no_invoice =$this->input->post('no_invoice');
		$this->Invoice_model->simpan_invoice($no_invoice);
		redirect('Invoice');
	}


}
?>