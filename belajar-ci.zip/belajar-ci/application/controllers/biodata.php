<?php
class biodata extends CI_controller
{
	function Biodata()
	{
		echo "Nama Mahasiswa : mangaraja jose <br>";
		echo "Alamat         : wisma jaya jln kusuma barat blok bb7 no 9 <br>";
		echo "Prodi          : MI <br>";
		echo "Kode Kelas     : 05421 <br>";
	}

}




?>