<?php
class hello extends CI_controller
{
	
	function index()
	{
		echo "Hello CI";
	}
	function Biodata()
	{
		echo "Nama Mahasiswa : Albert <br>";
		echo "Alamat         : Pondok Ungu <br>";
		echo "Prodi          : MI <br>";
		echo "Kode Kelas     : 05421";
	}
	function PersegiPanjang()
	{
		echo "Panjang  : 10 <br>";
		echo "Lebar    : 5 <br>";
		echo "Rumus    : K= P x L = 10 x 5 <br>";
		echo "Hasilnya : 50";
	}
	function Hitung()
	{
		$p=10;
		$l=2;
		$luas=$p*$l;
		echo "Panjang : ".$p." <br>";
		echo "Lebar   : ".$l." <br>";
		echo "Luas    : ".$luas;
	}
}




?>