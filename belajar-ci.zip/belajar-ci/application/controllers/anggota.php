<?php
class anggota extends CI_controller
{
		function index()
	{
		echo "Hello CI<br>";
		echo "Nama Mahasiswa : mangaraja jose <br>";
		echo "Alamat         : wisma jaya jln kusuma barat blok bb7 no 9 <br>";
		echo "Prodi          : MI <br>";
		echo "Kode Kelas     : 05421 <br>";
	}
}




?>