<?php
class Transaksi_list extends CI_Controller
{
    function __construct()
  {
    parent ::__construct();
    $this->load->model('Transaksi_list_model');
  }
  function index()
  {
    $data['transaksi']=$this->Transaksi_list_model->get_tampil_list();
    $this->load->view('transaksi_list_view',$data);
  }
}
?>

  ?>

