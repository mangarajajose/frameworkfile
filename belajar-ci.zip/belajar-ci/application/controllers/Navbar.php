<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Navbar extends CI_controller{


	public function index()
	{
		$this->load->view('Navbar_view');
	}
}
?>