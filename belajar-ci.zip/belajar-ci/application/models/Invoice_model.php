<?php
class Invoice_model extends CI_Model
{
	
	function get_no_invoice()
	{
		$q=$this->db->query("select max(right(no_invoice,5)) as kd_max
			from invoice where date(tanggal)=CURDATE()");
		$kd="";
		if ($q->num_rows()>0)
		{
			foreach($q->result() as $k)
			{
				$tmp= ((int)$k->kd_max)+1;
				$kd=sprintf("%05s",$tmp);
			}
		}else {
			$kd="00001";
		}
	
		date_default_timezone_get("Asia/Jakarta");
		return "FK".date('dmy').$kd;
	}
	function simpan_invoice($no_invoice)
	{
		$hasil=$this->db->query("insert into invoice (no_invoice) values('$no_invoice')");
		return $hasil;
	}

}
?>