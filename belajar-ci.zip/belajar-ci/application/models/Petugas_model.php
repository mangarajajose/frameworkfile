<?php
class Petugas_model extends CI_Controller
{
	
	function tampil_data()
{
		$hasil=$this->db->get('Petugas');

		return $hasil;
}
	
	function hapus_data($kode_petugas)
{
	$this->db->where('kode_petugas',$kode_petugas);
	$this->db->delete('Petugas');		
}
	function get_data_id($kode_petugas)
{
	$query=$this->db->get_where('petugas',array('kode_petugas'=>$kode_petugas));
	return $query;		
}
	function update($kode_petugas,$petugas,$shift)
	{
		$data=array(
		'kode_petugas'=>$kode_petugas,
		'petugas'=>$petugas,
		'shift'=>$shift);
		$this->db->where('kode_petugas',$kode_petugas);
	
		$this->db->update('Petugas',$data);
	}
	function get_tampil_data()
	{
		$hasil=$this->db->get('Petugas')->result();
		return $hasil;
	}
		function get_kode_petugas()
	{
		$q=$this->db->query("select max(right(kode_petugas,3)) as kd_max
			from petugas order by kode_petugas desc");
		$kd="";
		if ($q->num_rows()>0)
		{
			foreach($q->result() as $k)
			{
				$tmp= ((int)$k->kd_max)+1;
				$kd=sprintf("%03s",$tmp);
			}
		}else {
			$kd="001";
		}
	
		return "PET".$kd;
	}
	function simpan_petugas($kode_petugas,$petugas,$shift)
	{
		$hasil=$this->db->query("insert into petugas (kode_petugas,petugas,shift) values('$kode_petugas','$petugas','$shift')");
		return $hasil;
	}

}
?>