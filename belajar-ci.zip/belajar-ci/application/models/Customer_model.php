<?php
class Customer_model extends CI_Model
{
	
	function tampil_data()
{
		$hasil=$this->db->get('Customer');

		return $hasil;
}
	function hapus_data($kode_customer)
{
	$this->db->where('kode_customer',$kode_customer);
	$this->db->delete('Customer');		
}
	function get_data_id($kode_customer)
{
	$query=$this->db->get_where('Customer',array('kode_customer'=>$kode_customer));
	return $query;		
}
	function update($kode_customer,$nama_customer)
	{
		$data=array(
		'kode_customer'=>$kode_customer,
		'nama_customer'=>$nama_customer);
		$this->db->where('kode_customer',$kode_customer);
	
		$this->db->update('Customer',$data);
	}
	function get_tampil_data()
	{
		$hasil=$this->db->get('Customer')->result();
		return $hasil;
	}
	function get_kode_customer()
	{
		$q=$this->db->query("select max(right(kode_customer,3)) as kd_max
			from Customer order by kode_customer desc");
		$kd="";
		if ($q->num_rows()>0)
		{
			foreach($q->result() as $k)
			{
				$tmp= ((int)$k->kd_max)+1;
				$kd=sprintf("%03s",$tmp);
			}
		}else {
			$kd="001";
		}
	
		return "CUS".$kd;
	}
	function simpan_customer($kode_customer,$nama_customer)
	{
		$hasil=$this->db->query("insert into customer (kode_customer,nama_customer) values('$kode_customer','$nama_customer')");
		return $hasil;
	}
}

?>