<?php
class Barang_model extends CI_Model
{
	
	function tampil_data()
{
		$hasil=$this->db->get('barang');

		return $hasil;
}
	function hapus_data($Barang_id)
{
	$this->db->where('Barang_id',$Barang_id);
	$this->db->delete('Barang');		
}
	function get_data_id($Barang_id)
{
	$query=$this->db->get_where('Barang',array('Barang_id'=>$Barang_id));
	return $query;		
}
	function update($Barang_id,$Nama_barang,$Harga_barang)
	{
		$data=array(
		'Barang_id'=>$Barang_id,
		'Nama_barang'=>$Nama_barang,
		'Harga_barang'=>$Harga_barang);
		$this->db->where('Barang_id',$Barang_id);
	
		$this->db->update('Barang',$data);
	}
	function get_tampil_data()
	{
		$hasil=$this->db->get('barang')->result();
		return $hasil;
	}
	function get_no_barang()
	{
		$q=$this->db->query("select max(right(Barang_id,5)) as kd_max
			from barang order by Barang_id desc");
		$kd="";
		if ($q->num_rows()>0)
		{
			foreach($q->result() as $k)
			{
				$tmp= ((int)$k->kd_max)+1;
				$kd=sprintf("%05s",$tmp);
			}
		}else {
			$kd="00001";
		}
	
		return "BRG".$kd;
	}
	function simpan_barang($Barang_id,$Nama_barang,$Harga_barang)
	{
		$hasil=$this->db->query("insert into barang (Barang_id,Nama_barang,Harga_barang) values('$Barang_id','$Nama_barang','$Harga_barang')");
		return $hasil;
	}
}

?>