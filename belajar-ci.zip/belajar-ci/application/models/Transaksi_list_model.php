<?php
class Transaksi_list_model extends CI_Model
{
  function get_tampil_list()
      {
        $hasil=$this->db->get('transaksi');
        return $hasil;
      }
}
  ?>
