<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>update petugas</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="container">
			<h1><center>Edit petugas</center></h1>
			<div class="col-md-6 offset-md-3">
				<form action="<?php echo site_url('petugas/update');?>" method="post">
				<!--Group Komponen Form-->
				<div class="form-group">
				<label>kode customer</label>
				<input type="text" name="kode petugas" value="<?php echo $kode_petugas;?>" readonly>
				</div>
				<div class="form-group">
				<label>petugas</label>
				<input type="type" class="form-control" name="petugas" value="<?php echo $petugas;?>" placeholder="petugas">		
				</div>
				<div class="form-group">
				<label>shift</label>
				<input type="type" class="form-control" name="shift" value="<?php echo $shift;?>" placeholder="shift">		
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
				</form>
			</div>
			</div>
		</div>
		<!--Aktifkan JS file-->
		<script type="text/javascript"
		src="<?php echo base_url('assets/js/jquery.min.js');?>">
		</script>
		<script type="text/javascript"
		src="<?php echo base_url('assets/css/bootstrap.min.css');?>">
		</script>	
</body>	
</html>