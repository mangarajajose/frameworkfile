<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>Customer List</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="container">
			<h1><center>Customer list</center></h1>
			<div class="col-md-6 offset-md-3">
				<form action="<?php echo base_url('Customer/simpan_customer')?>"
		method="post">
				<!--Group Komponen Form-->
				<label>kode customer</label>
				<input type="text" name="kode_customer" value="<?php echo $Customer;?>" readonly>
				<div class="form-group">
				<label>nama customer</label>
				<input type="type" class="form-control" name="nama_customer" placeholder="nama customer">		
				</div>
				<button type="submit">Simpan</button>
				</form>
			</div>
			</div>
		</div>
		<!--Aktifkan JS file-->
		<script type="text/javascript"
		src="<?php echo base_url('assets/js/jquery.min.js');?>">
		</script>
		<script type="text/javascript"
		src="<?php echo base_url('assets/css/bootstrap.min.css');?>">
		</script>	
</body>	
</html>