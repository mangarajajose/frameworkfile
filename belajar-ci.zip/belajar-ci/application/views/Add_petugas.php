<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>ADD petugas</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="container">

			<h1><center>Add petugas baru</center></h1>
			<div class="col-md-6 offset-md-3">
				<form action="<?php echo site_url('Petugas/simpan_petugas');?>" method="post">

				<!--Group Komponen Form-->
				<label>Kode Petugas</label>
				<input type="text" name="kode petugas" value="<?php echo $Petugas;?>" readonly>
				<div class="form-group">
				<label>petugas</label>
				<input type="type" class="form-control" name="petugas" placeholder="petugas">		
				</div>
				<div class="form-group">
				<label>shift</label>
				<input type="type" class="form-control" name="shift" placeholder="shift">	
				<button type="submit">simpan</button>	
				</div>
				</form>
			</div>
			</div>
		</div>
		<!--Aktifkan JS file-->
		<script type="text/javascript"
		src="<?php echo base_url('assets/js/jquery.min.js');?>">
		</script>
		<script type="text/javascript"
		src="<?php echo base_url('assets/css/bootstrap.min.css');?>">
		</script>	
</body>	
</html>