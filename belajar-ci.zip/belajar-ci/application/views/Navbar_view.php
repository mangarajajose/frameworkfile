<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>aplikasi kelola barang</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
	<!--fonts-->
	<link href="<?php echo base_url('assets/css/font-awesome.css');?>"
	rel="stylesheet">
</head>

	<nav class="navbar navbar-expand navbar-expand navbar-dark
	bg-success static-top">

<!---navbar-->

<ui class="navbar-nav ml-auto ml-md-0">
<li class="nav-item dropdown no arrow">
<a class="nav-link textbox-toggle" href="<?php echo base_url('Barang');?>"
	id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
	aria-expanded="false">
	<i class="fa fa-book"></i>Data kelola Barang
</a>
</li>
<ui class="navbar-nav ml-auto ml-md-0">
<li class="nav-item dropdown no arrow">
<a class="nav-link textbox-toggle" href="<?php echo base_url('Petugas');?>"
	id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
	aria-expanded="false">
	<i class="fa fa-suitcase"></i>Data kelola petugas
</a>
</li>

<li class="nav-item dropdown no-arrow">
	<a class="nav-link textbox-toggle" href="<?php echo base_url('anggota');?>" id="userDropdown" role="button"
	data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	<i class="fa fa-user"></i> biodata programmer

		</a>
	</li>

	</li>
<ui class="navbar-nav ml-auto ml-md-0">
<li class="nav-item dropdown no arrow">
<a class="nav-link textbox-toggle" href="<?php echo base_url('Customer');?>"
	id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
	aria-expanded="false">
	<i class="fa fa-check"></i>Data kelola customer
</a>
</li>

</li>
<ui class="navbar-nav ml-auto ml-md-0">
<li class="nav-item dropdown no arrow">
<a class="nav-link textbox-toggle" href="<?php echo base_url('Transaksi');?>"
	id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
	aria-expanded="false">
	<i class="fa fa-money"></i>Data Transaksi
</a>
</li>

</li>
<ui class="navbar-nav ml-auto ml-md-0">
<li class="nav-item dropdown no arrow">
<a class="nav-link textbox-toggle" href="<?php echo base_url('Transaksi_list');?>"
	id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
	aria-expanded="false">
	<i class="fa fa-check"></i>list transaksi
</a>
</li>

</ui>

</nav>
</html>