<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $title;?>
	</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="jumbotron jumbotron-fluid">
		<div class="container">
			<h1><?php echo $content;?></h1>
		</div>
		</div>
	</div>	
</body>	
</html>