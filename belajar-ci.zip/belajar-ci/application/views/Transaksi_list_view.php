<!DOCTYPE html>
<html lang="en">

<link href="<?php echo base_url('assets/img/logoriel.ico');?>"rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>Barang List</title>
	<!--Load Bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		
        <div class="container">	
        <div class="col-md-6 offset-md-3">
        <h1><center>Transaksi List</center></h1>
    </div>
        <table class="table table-striped">
        <thead>
        	      

       	<tr>
           <th scope="col">No Faktur</th>
           <th scope="col">Kode Barang</th>
           <th scope="col">Nama Barang</th>
           <th scope="col">Harga Barang</th>
           <th scope="col">Qty</th>
           <th scope="col">Sub Total</th>
           	
       	</tr>
        </thead>
        <!--Tampil Data-->
       <?php
        $no=0;
        foreach($transaksi->result() as $row):
        $no++;
        ?>
        	<th scope="row"><?php echo $row->faktur;?>
        	</th>
            <td><?php echo $row->barang_id;?>
            </td>
        	<td><?php echo $row->nama_barang;?>
        	</td>
            <td><?php echo number_format($row->harga_barang);?>
            </td>
            </td>
        	<td><?php echo number_format($row->qty);?>
        	</td>
            <td><?php echo number_format($row->subtotal);?>
            </td>
        </tr>
            <!--Akhir Baca Data-->
            <?php endforeach;
            ?>
        
        </table>

        </div>
    </div>


    <!-- Mengaktifkan JS File-->
    <script type="text/javascript"
    src="<?php echo base_url('assets/js/jquery.min.js');?>">
    </script>
    <!-- Mengaktifkan Bootstrap File-->
   <script type="text/javascript"
   src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>
