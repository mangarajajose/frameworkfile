<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>petugas list</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="container mt-2">
			<h1><center>petugas List</center></h1>
			<table class="table table-success">
			<thead>
				<a href="<?php echo site_url ('Petugas/Add_petugas');?>"
					class="btn btn-warning">ADD</a>
					<a href="<?php echo site_url ('Navbar');?>"
					class="btn btn-dark">home</a>
			<tr>
				<th scope="col-md-6">#</th>
				<th scope="col-md-6">kode petugas</th>
				<th scope="col-md-6">petugas</th>
				<th scope="col-md-6">shift</th>
				<th scope="col-md-6">Action</th>
			</tr>	
			</thead>
			<!--Tampil Data-->
			<?php
			$no=0;
			foreach($Petugas->result() as $row) :
			$no++;
			?>
			<tr>
				<th scope="row"><?php echo $no;?>
				</th>
				<td><?php echo $row->kode_petugas;?>
				</td>
				<td><?php echo $row->petugas;?>
				</td>
				<td><?php echo $row->shift;?>
				</td>
				<td><a href="<?php echo site_url('Petugas/Edit_petugas/'.$row->kode_petugas);?>"
					class="btn btn-primary">UPDATE</a>
				<a href="<?php echo site_url('Petugas/Delete_petugas/'.$row->kode_petugas);?>"
					class="btn btn-danger">DELETE</a>	
			</td>
			</tr>
			<!--Akhir baca data-->
			<?php endforeach;
			?>
			</table>
			</div>
		</div>
		<!--Aktifkan JS file-->
		<script type="text/javascript"
		src="<?php echo base_url('assets/js/jquery.min.js');?>">
		</script>
		<script type="text/javascript"
		src="<?php echo base_url('assets/css/bootstrap.min.css');?>">
		</script>	
</body>	
</html>