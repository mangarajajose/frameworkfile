<?php
defined('BASEPATH') or exit('No direct script access allowed');
?><!DOCTYPE html>
	<html lang="en">
<link  href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylsheet">

<head>
	<meta charset="utf-8">
	<title>Biodata</title>
</head>
<body>
	<div class="col-md-6 offset-md-3" id="container">
		<h1>Biodata</h1>
	</div>
	<div class="col-md-6 offset-md-3" id="body">
		<ul class="list-group list-group-flush">
			<li class="list-group-item">Nim :
				<?php echo $nim;?>
			</li>
			<li class="list-group-item">Nama :
				<?php echo $nama;?>
			</li>
			<li class="list-group-item">program studi :
				<?php echo $program_studi;?>
			</li>
			<li class="list-group-item">kode kelas :
				<?php echo $kode_Kelas;?>
			</li>
			<li class="list-group-item">alamat :
				<?php echo $alamat;?>
			</li>
			<li class="list-group-item">soal :
				<?php echo $soal;?>
			</li>
</ul>

</div>

</body>
</html>