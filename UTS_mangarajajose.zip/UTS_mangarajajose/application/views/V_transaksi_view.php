<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url ('assets/img/barang.ico') ?>" rel="shortcut icon" >	
<head>
	<meta charset="utf-8">
	<title>List Transaksi</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="container">
			<center><h1 style="background-color:Tomato;">Data View Transaksi</h1></center>
<!--TOMBOL HOME NAVBAR-->
<a href="<?php echo base_url('Navbarcustomer')?>" class="btn btn-info">HOME</a>
<!--membuka table-->
			<table class="table table-dark">
				<thead>
					<tr>
						<th scope="col">NO</th>
						<th scope="col">No Faktur</th>
						<th scope="col">Kode Barang</th>
						<th scope="col">Nama Barang</th>
						<th scope="col">Harga</th>
						<th scope="col">QTY</th>
						<th width="col">SubTotal</th>
					</tr>
				</thead>
<!--tampil data-->
				<?php
				$no=0;
				foreach ($v_transaksi->result() as $row) :
				$no++;
				?>
				 <tr>
				 	<th scope="row"><?php echo $no;?></th>
				 	<td><?php echo $row->faktur; ?></td>
				 	<td><?php echo $row->barang_id;?></td>
				 	<td><?php echo $row->nama_barang;?></td>
				 	<td><?php echo number_format ($row->harga_barang); ?></td>
				 	<td><?php echo $row->qty; ?></td>
				 	<td><?php echo number_format ($row->subtotal); ?></td>
				 </tr>

<!--AKHIR BACA DATA-->
				 <?php endforeach;
				 ?>
			</table>
			
		</div>
	</div>
	<!--aktifkan javascript file-->
	<script type="text/javascript"
	src="<?php echo base_url('assets/js/jquery.min.js');?>"></script>
	<!--aktifkan bootstrap-->
	<script type="text/javascript"
	src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>