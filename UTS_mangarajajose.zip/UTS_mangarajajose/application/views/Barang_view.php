<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>Barang List</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="container">
			<h1><center>Barang List</center></h1>
			<table class="table table-success">
			<thead>
				<a href="<?php echo site_url ('Barang/Add_barang');?>"
					class="btn btn-warning">ADD</a>
					<a href="<?php echo site_url ('Navbarcustomer');?>"
					class="btn btn-dark">home<br></a>
			<tr>
				<th scope="col-md-6">no</th>
				<th scope="col-md-6">Barang id</th>
				<th scope="col-md-6">Nama Barang</th>
				<th scope="col-md-6">Harga Barang</th>
				<th scope="col-md-6">Action</th>
			</tr>	
			</thead>
			<!--Tampil Data-->
			<?php
			$no=0;
			foreach($Barang->result() as $row) :
			$no++;
			?>
			<tr>
				<th scope="row"><?php echo $no;?>
				</th>
				<td><?php echo $row->barang_id;?>
				</td>
				<td><?php echo $row->nama_barang;?>
				</td>
				<td><?php echo number_format($row->harga_barang);?>
				</td>
				<td><a href="<?php echo site_url('Barang/Edit_barang/'.$row->barang_id);?>"
					class="btn btn-primary">UPDATE</a>
				<a href="<?php echo site_url('Barang/Delete_barang/'.$row->barang_id);?>"
					class="btn btn-danger">DELETE</a>	
			</td>
			</tr>
			<!--Akhir baca data-->
			<?php endforeach;
			?>
			</table>
			</div>
		</div>
		<!--Aktifkan JS file-->
		<script type="text/javascript"
		src="<?php echo base_url('assets/js/jquery.min.js');?>">
		</script>
		<script type="text/javascript"
		src="<?php echo base_url('assets/css/bootstrap.min.css');?>">
		</script>	
</body>	
</html>