<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>Edit customer</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="container">
			<h1><center>Edit customer</center></h1>
			<div class="col-md-6 offset-md-3">
				<form action="<?php echo site_url('Customer/update');?>" method="post">
				<!--Group Komponen Form-->
				<div class="form-group">
				<label>nama_customer</label>
				<input type="type" class="form-control" name="nama_customer" value="<?php echo $nama_customer;?>" placeholder="nama customer">		
				</div>
				<div class="form-group">
				<label>alamat</label>
				<input type="type" class="form-control" name="alamat" value="<?php echo $alamat;?>" placeholder="alamat">		
				</div>
				<label>telepon</label>
				<input type="type" class="form-control" name="telepon" value="<?php echo $telepon;?>" placeholder="telepon">		
				</div>
				<input type="hidden" name="kode_customer"
				value="<?php echo $kode_customer;?>">

				<center><button type="submit" class="btn btn-primary">Submit</button><center>
				</form>
			</div>
			</div>
		</div>
		<!--Aktifkan JS file-->
		<script type="text/javascript"
		src="<?php echo base_url('assets/js/jquery.min.js');?>">
		</script>
		<script type="text/javascript"
		src="<?php echo base_url('assets/css/bootstrap.min.css');?>">
		</script>	
</body>	
</html>