<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>Kelola Data Customer</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<div>
		<div class="container mt-2">
			<h1><center>Kelola Data Customer</center></h1>
			<table class="table table-success">
			<thead>
				<a href="<?php echo site_url ('Customer/Add_customer');?>"
					class="btn btn-warning">ADD</a>
					<a href="<?php echo site_url ('Navbarcustomer');?>"
					class="btn btn-dark">HOME</a>
			<tr>
				<th scope="col-md-6">#</th>
				<th scope="col-md-6">kode_customer</th>
				<th scope="col-md-6">nama_customer</th>
				<th scope="col-md-6">alamat</th>
				<th scope="col-md-6">telepon</th>
				<th scope="col-md-6">Aksi</th>
			</tr>	
			</thead>
			<!--Tampil Data-->
			<?php
			$no=0;
			foreach($Customer->result() as $row) :
			$no++;
			?>
			<tr>
				<th scope="row"><?php echo $no;?>
				</th>
				<td><?php echo $row->kode_customer;?>
				</td>
				<td><?php echo $row->nama_customer;?>
				</td>
				<td><?php echo $row->alamat;?>
				</td>
				<td><?php echo $row->telepon;?>
				</td>
				<td><a href="<?php echo site_url('Customer/Edit_customer/'.$row->kode_customer);?>"
					class="btn btn-primary">EDIT</a>
				<a href="<?php echo site_url('Customer/Delete_customer/'.$row->kode_customer);?>"
					class="btn btn-danger">DELETE</a>	
			</td>
			</tr>
			<!--Akhir baca data-->
			<?php endforeach;
			?>
			</table>
			</div>
		</div>
		<!--Aktifkan JS file-->
		<script type="text/javascript"
		src="<?php echo base_url('assets/js/jquery.min.js');?>">
		</script>
		<script type="text/javascript"
		src="<?php echo base_url('assets/css/bootstrap.min.css');?>">
		</script>	
</body>	
</html>