<!DOCTYPE html>
<html lang="en">
<link href="<?php echo base_url('assets/img/logo.ico')?>"
	rel="shortcut icon">
<head>
	<meta charset="utf-8">
	<title>Transaksi</title>
	<!--load bootstrap-->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
	rel="stylesheet">
</head>
<body>
	<?php
	$this->load->view('Navbar_bagus');
	?>
<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<center><?php echo $this->session->flashdata('msg');?></center> 
			<h1 class="page-header">Transaksi Penjualan</h1>
			<div class="modal-body">
				<label class="control-label col-lg-8">No. Faktur
				</label>
				<div class="col-lg-8">
					<input type="faktur" class="form-control" id="faktur"
					type="text" style="width:150px"
					value="<?php echo $faktur;?>" readonly> 
				</div>
				<label class="control-label col-lg-8">Kode Customer
				</label>
				<div class="col-lg-8">
					<select type="kode_customer" class="form-control" id="kode_customer"
					type="text" style="width:200px">
					<option value="0">Pilih Customer....</option>
					<?php foreach($Customer as $row):?>
					<option value="<?php echo $row->kode_customer;?>">
						<?php echo $row->kode_customer;?>-<?php echo $row->nama_customer;?>
					</option>
					<?php endforeach;?>
			</select>
			</div>
			<!--koding untuk nama customer-->
			<label class="control-label col-lg-8">Nama Customer
			</label>
			<div class="col-lg-8">
				<input name="nama_customer" class="form-control"
				id="nama_customer" type="text" style="width: 200px"
				values="" readonly>
			</div>
			<!--akhir koding untuk nama customer-->
			<label class="control-label col-lg-8">Kode Barang
				</label>
				<div class="col-lg-8">
					<select type="kode_barang" class="form-control" id="kode_barang"
					type="text" style="width:230px">
					<option value="0">Pilih Barang....</option>
					<?php foreach($Barang as $row):?>
					<option value="<?php echo $row->barang_id;?>">
						<?php echo $row->barang_id;?>-<?php echo $row->nama_barang;?>
					</option>
					<?php endforeach;?>
			</select>
			</div>
			<div>
			<div class="col-lg-8">
				<input name="barang" id="barang" class="form-control"
				type="text" style="width: 200px">
				<input name="nama_barang" id="nama_barang" class="form-control"
				type="text" style="width: 200px">
				<input name="harga_barang" id="harga_barang" class="form-control"
				type="text" style="width: 200px">
				<input name="qty" id="qty" class="form-control"
				type="text" value="1" style="width: 50px">
			</div>
			<!--Coding Pilih dan Hitung-->
        <table>
        <tr><td><button class="add_cart btn btn-success btn-block" style="width:100px">Pilih</button>
        <td><td><td> -- <td><button class="hitung_cart btn btn-success btn-block" onclick="location.reload()" style="width:100px">Hitung</button>
        </td></tr>
        </table>
		</div>
	</div>
</div>
		
		
        <!--Coding Detail Transaksi-->
        <div class="col-lg-12"> 
        <table class="table table-bordered table-condensed" style="font-size:12px;margin-top:10px;
        background-color: white;">
                <thead>
                    <tr>
                              <th>No.</th>
                              <th>Kode Barang</th>
                              <th>Nama Barang</th>
                              <th style="text-align:center;">Harga Barang (Rp)</th>
                              <th style="text-align:center;">Qty</th>
                              <th style="width:100px;text-align:center;">Biaya(Rp)</th>
                        <th style="width:150px;text-align:center;">Aksi</th>
                    </tr>
                </thead>
                <tbody id="detail_cart">
                </tbody>
            </table>
            <table>
            <tr>
               <form action="<?php echo base_url().'Transaksi/simpan_transaksi'?>" method="post">
                    <td style="width:760px;" rowspan="2"><button type="submit" class="btn btn-info btn-lg"> Simpan</button></td>
                         <th style="width:140px;">Sub Total(Rp)</th>
                    <th style="text-align:right;width:140px;"><input type="text" id="total2" name="total2" value="<?php echo number_format($this->cart->total());
                ?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly>
                         <input type="hidden" id="faktur2" name="faktur2" value="<?php echo $faktur;?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly>
                          <input type="hidden" id="faktur2" name="customer2" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly>
                         <input type="hidden" id="total" name="total" value="<?php echo $this->cart->total();?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly>
                    </tr>
                     <tr>
                         <tr>
                    <td></td>
                    <th>PPN 10%(Rp)</th>
                    <th style="text-align:right;"><input type="text" id="ppn" name="ppn" class="ppn form-control input-sm" 
                         value="<?php echo number_format($this->cart->total()*10/100);
                ?>"
                style="text-align:right;margin-bottom:5px;" readonly></th>
                    <input type="hidden" id="ppn2" name="ppn2" class="form-control input-sm" 
                    style="text-align:right;margin-bottom:5px;" required> 
                    </tr>
                    <tr>
                    <td></td>
                    <th>Total Bayar(Rp)</th>
                    <th style="text-align:right;"><input type="text" id="total_bayar" name="total_bayar" class="total_bayar form-control input-sm" 
                    value="<?php echo number_format($this->cart->total()+$this->cart->total()*10/100);
                ?>"
                    style="text-align:right;margin-bottom:5px;" readonly></th>
                    <input type="hidden" id="total_bayar2" name="total_bayar2" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" required>
                         
                    </tr>
                <tr>
                    <td></td>
                    <th>Uang Bayar (Rp) *</th>
                    <th style="text-align:right;"><input type="text" id="jml_uang" name="jml_uang" autocomplete="off" class="jml_uang form-control input-sm" style="text-align:right;margin-bottom:5px;" required></th>
                    <input type="hidden" id="jml_uang2" name="jml_uang2" class="form-control input-sm" onkeyup="angka(this);" style="text-align:right;margin-bottom:5px;" autocomplete="off" readonly>
                         
                    </tr>
                    
                <tr>
                    <td></td>
                    <th>Sisa(Rp)</th>
                    <th style="text-align:right;"><input type="text" id="kembalian" name="kembalian" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly></th>
                </tr>
            </table>
       </form>
            <hr/>
        </div>
        <!--Akhir Detail Tabel transaksi-->

			
		<!--jquery-->
		<script src="<?php echo base_url().'assets/js/jquery.js'?>"></script>
		<script type="text/javascript">
		
		$(document).ready(function()
		{
			$('#kode_customer').change(function()
		{
			var	customer=$(this).val();
			//alert(customer);
			$.ajax(
		{
		url : "<?php echo base_url('Transaksi/get_customer')?>",
		method 	 :"POST",
		dataType :'json',
				data:{kode:customer},
				cache:false,
		async :true,
				success:function(data)
			{
				$.each(data,function(kode_customer,nama_customer)
				{
					$('[name="nama_customer"]').val(data.nama_customer);
					$('[name="customer2"]').val(data.kode_customer);
				});
			}
		})

return false
	});	
	});
		</script>
		<script src="<?php echo base_url().'assets/js/jquery.js'?>"></script>
		<script type="text/javascript">
		
		$(document).ready(function()
		{
			$('#kode_barang').change(function()
		{
			var	barang=$(this).val();
			//alert(customer);
			$.ajax(
		{
		url : "<?php echo base_url('Transaksi/get_barang')?>",
		method 	 :"POST",
		dataType :'json',
				data:{kode:barang},
				cache:false,
		async :true,
				success:function(data)
			{
				$.each(data,function(barang_id,nama_barang,harga_barang)
				{
					$('[name="barang"]').val(data.barang_id);
					$('[name="nama_barang"]').val(data.nama_barang);
					$('[name="harga_barang"]').val(data.harga_barang);
				});
			}
		})

return false
	});	
	});
		</script>
		<script src="<?php echo base_url().'assets/js/jquery.js'?>"></script>
		<script type="text/javascript">
		
		$(document).ready(function()
		{
			$('#nama_barang').change(function()
		{
			var	barang=$(this).val();
			//alert(customer);
			$.ajax(
		{
		url : "<?php echo base_url('Transaksi/get_barang')?>",
		method 	 :"POST",
		dataType :'json',
				data:{nama:barang},
				cache:false,
		async :true,
				success:function(data)
			{
				$.each(data,function(barang_id,nama_barang,harga_barang)
				{
					$('[name="barang"]').val(data.barang_id);
					$('[name="nama_barang"]').val(data.nama_barang);
					$('[name="harga_barang"]').val(data.harga_barang);
				});
			}
		})

return false
	});	
	});
		</script>
		<!--coding detail tabel Transaksi-->
          <script type="text/javascript">
    $(document).ready(function(){
        $('.add_cart').click(function(){
          var faktur=$('#faktur2').val();
            var kode=$('#barang').val();
            var nama_barang=$('#nama_barang').val();
            var harga=$('#harga_barang').val();
            var qty=$('#qty').val();
            var total=$('#total2').val();
            $.ajax
               ({
                url : "<?php echo base_url().'Transaksi/add_to_cart'?>",
                method : "POST",
                data :{faktur:faktur,kode:kode,nama_barang:nama_barang,harga:harga,qty:qty},
                success: function(data){
                    $('#detail_cart').html(data);
                }
            });
        });
        // Load shopping cart
        $('#detail_cart').load("<?php echo base_url().'Transaksi/load_cart'?>");
        //Hapus Item Cart
        $(document).on('click','.hapus_cart',function(){
            var row_id=$(this).attr("id"); //mengambil row_id dari artibut id
            $.ajax({
                url : "<?php echo base_url().'Transaksi/hapus_cart'?>",
                method : "POST",
                data : {row_id:row_id},
                success :function(data){
                    $('#detail_cart').html(data);
                }
            });
        });
    });
</script>

<!--Coding jumlah Uang-->
    <script src="<?php echo base_url().'assets/js/jquery.price_format.min.js'?>"></script>
<script type="text/javascript">
        $(function(){
            $('#jml_uang').on("input",function(){
                var bayar=$('#total_bayar').val();
                var jumuang=$('#jml_uang').val();
                var hsl3=jumuang.replace(/[^\d]/g,"");
                    var bayar3=bayar.replace(/[^\d]/g,"");
                $('#jml_uang2').val(hsl3);
                    $('#total_bayar2').val(bayar3);
                $('#kembalian').val(hsl3-bayar3);
            })
        });
    </script>
</body>
</html>