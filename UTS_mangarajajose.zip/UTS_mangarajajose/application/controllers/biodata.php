<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Biodata extends CI_controller
{
	public function index()
	{

		
		$data = array(
		 'nim'            => '200441050015',
		 'nama' => 'mangaraja jose',
	 	 'program_studi'  => 'TI',
		 'kode_Kelas'     => '05421',
		 'alamat'         => 'wisma jaya jln kusuma barat blok bb7 no 9 kelurahan duren jaya',
		 'soal'      => 'TYPE A'
	);

		$this->load->view('Biodata_view',$data);
	}

}


?>