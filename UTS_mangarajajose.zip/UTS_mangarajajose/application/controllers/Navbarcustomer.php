<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Navbarcustomer extends CI_controller{


	public function index()
	{
		$this->load->view('Navbar_bagus');
	}
}
?>