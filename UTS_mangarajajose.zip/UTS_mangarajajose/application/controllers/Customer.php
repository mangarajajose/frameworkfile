<?php
class Customer extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Customer_model');
	}
	function index()
	{
		$data['Customer']=$this->Customer_model->
		tampil_data();
		$this->load->view('Customer_view',$data);	
	}
	function Simpan()
	{
		$kode_customer=$this->input->post('kode_customer');
		$nama_customer=$this->input->post('nama_customer');
		$alamat=$this->input->post('alamat');
		$telepon=$this->input->post('telepon');
		$this->Customer_model->Simpan($kode_customer,$nama_customer,$alamat,$telepon);
		redirect('Customer');
	}
	function Delete_customer()
	{
		$kode_customer=$this->uri->segment(3);	
		$this->Customer_model->hapus_data($kode_customer);
		redirect('Customer');	
	}
	function Edit_customer()
	{
		$kode_customer=$this->uri->segment(3);	
		$result=$this->Customer_model->get_data_id($kode_customer);
		if ($result->num_rows()>0) 
	{
			$i=$result->row_array();
			$data=array(
			'kode_customer'=>$i['kode_customer'],
			'nama_customer'=>$i['nama_customer'],
			'alamat'=>$i['alamat'],
			'telepon'=>$i['telepon']
	);
			$this->load->view('Edit_customer',$data);
	}
		else 
	{
			echo "Data Tidak Ditemukan";
	}
	}
	function update()
	{
		$kode_customer=$this->input->post('kode_customer');
		$nama_customer=$this->input->post('nama_customer');
		$alamat=$this->input->post('alamat');
		$telepon=$this->input->post('telepon');
		$this->Customer_model->update($kode_customer,$nama_customer,$alamat,$telepon);
		redirect('Customer');
	}
	function Add_customer()
	{
		$data['Customer']=$this->Customer_model->get_kode_customer();
		$this->load->view('Add_customer',$data);
	}				
}
?>