<?php 
class Barang_model extends CI_Model
{
    function tampil_data()
    {
      $hasil=$this->db->get('Barang');
      return $hasil;	
    }
    function hapus_data($barang_id)
    {
    $this->db->where('barang_id',$barang_id);
    $this->db->delete('Barang');
    }
    function get_tampil_data()
    {
      $hasil=$this->db->get('Barang')->result();
      return $hasil;	
    }
    function get_data_id($barang_id)
    {
    $query=$this->db->get_where('Barang',array('barang_id'=>$barang_id));
    return $query;
    }
    function update($barang_id,$nama_barang,$harga_barang)
    {
      $data=array(
       'barang_id'=>$barang_id,
       'nama_barang'=>$nama_barang,
       'harga_barang'=>$harga_barang);
       $this->db->where('barang_id',$barang_id);
       $this->db->update('Barang',$data) ;
    }
    function get_no_barang()
    {
    $q=$this->db->query("select max(right(barang_id,5)) as kd_max
        from barang order by barang_id desc");
    $kd="";
    if($q->num_rows()>0)
    {
    foreach ($q->result() as $k)
    {
      $tmp = ((int)$k->kd_max)+1;
      $kd=sprintf("%05s",$tmp);
    }
    }
      else
      {
        $kd="00001";
   }
   return "BRG".$kd;
 }
   function simpan_barang($barang_id,$nama_barang,$harga_barang)
   {
    $hasil=$this->db->query("insert into barang (barang_id,nama_barang,harga_barang) 
      Values('$barang_id','$nama_barang', '$harga_barang')");
    return $hasil;
}
}